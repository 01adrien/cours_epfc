create view livre_eponyme(idlivre, titre, extract, annee) as
SELECT lp.idlivre,
       lp.titre,
       EXTRACT(year FROM lp.date_parution) AS "extract",
       o.annee
FROM bdlivre.livre_paru lp
         JOIN bdlivre.oeuvre o ON o.idoeuvre = lp.numoeuvre
WHERE lp.titre::text = o.titre::text;

alter table livre_eponyme
    owner to postgres;

