create view livre_francais (idlivre, isbn, titre, editeur, langue, pays, date_parution, nb_pages, numoeuvre) as
SELECT l.idlivre,
       l.isbn,
       l.titre,
       l.editeur,
       l.langue,
       l.pays,
       l.date_parution,
       l.nb_pages,
       l.numoeuvre
FROM bdlivre.livre_paru l
WHERE l.langue::bpchar = 'Fr'::bpchar
with cascaded check option;

alter table livre_francais
    owner to postgres;

