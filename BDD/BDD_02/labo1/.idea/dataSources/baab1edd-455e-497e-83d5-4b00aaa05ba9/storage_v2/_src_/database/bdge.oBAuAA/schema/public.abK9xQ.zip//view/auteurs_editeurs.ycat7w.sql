create view auteurs_editeurs(prenom, nom, titre, editeur, date_parution) as
SELECT te.prenom,
       te.nom,
       o.titre,
       lp.editeur,
       lp.date_parution
FROM bdlivre.traducteur_ecrivain te
         JOIN bdlivre.ecrit_par ep ON ep.numecriv = te.idtrad_ecriv
         JOIN bdlivre.oeuvre o ON o.idoeuvre = ep.numoeuvre
         JOIN bdlivre.livre_paru lp ON o.idoeuvre = lp.numoeuvre
WHERE lp.editeur IS NOT NULL;

alter table auteurs_editeurs
    owner to postgres;

